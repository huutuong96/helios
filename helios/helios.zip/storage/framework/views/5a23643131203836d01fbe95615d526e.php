<div class="mega-container visible-lg visible-md visible-sm">
    <div class="navleft-container">
        <div class="mega-menu-title">
            <h3><i class="fa fa-navicon"></i>Danh Mục</h3>
        </div>
        <div class="mega-menu-category">
            <ul class="nav">
                <li class="nosub"><a href="<?php echo e(route("index")); ?>">TRANG CHỦ</a></li>
                <li class="nosub"><a href="<?php echo e(route("shop")); ?>">CỬA HÀNG</a></li>
                <li class="nosub"><a href="<?php echo e(route("blog")); ?>">BÀI VIẾT</a></li>
            </ul>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\du_an_1\laravel\helios\resources\views/FrontEnd/models/mega_menu.blade.php ENDPATH**/ ?>